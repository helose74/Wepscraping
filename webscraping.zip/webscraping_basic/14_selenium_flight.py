from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

browser = webdriver.Chrome()
browser.maximize_window()

# 1. 네이버 항공권으로 이동
url = "https://flight.naver.com/flights/"
browser.get(url)

# 2. 날짜 선택
browser.find_element_by_link_text("가는날 선택").click()

# 3. 다음달 27, 28 일 선택
browser.find_elements_by_link_text("27")[1].click()
browser.find_elements_by_link_text("28")[1].click()

# 4. 출발 : 김포 선택
browser.find_element_by_xpath("//*[@id='l_1']/div/div[1]/a[2]").click()
browser.find_element_by_xpath("//*[@id='l_1']/div/div[1]/div[2]/table[1]/tbody/tr[1]/td[3]/a").click()

# 5. 도착 : 제주도 선택
browser.find_element_by_xpath("//*[@id='l_1']/div/div[2]/a[2]").click()
browser.find_element_by_xpath("//*[@id='l_1']/div/div[2]/div[2]/table[1]/tbody/tr[1]/td[1]/a").click()

# 6. 항공권 검색
browser.find_element_by_link_text("항공권 검색").click()

# 7. 결과 출력
try:
    elem = WebDriverWait(browser, 10).until(EC.presence_of_element_located((By.XPATH, "//*[@id='content']/div[2]/div/div[4]")))
    
    for result_num in range(1,6):
        result = browser.find_element_by_xpath("//*[@id='content']/div[2]/div/div[4]/ul/li[{}]".format(result_num))
        print(result.text)

finally:
    browser.quit()
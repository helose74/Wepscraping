from selenium import webdriver
import requests
from bs4 import BeautifulSoup

options = webdriver.ChromeOptions()
options.headless = True
options.add_argument("window-size=1920x1080")
options.add_argument("user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.182 Safari/537.36")

browser = webdriver.Chrome(options=options)
browser.maximize_window()

url = "http://daum.net"
browser.get(url)

browser.find_element_by_id("q").send_keys("송파 헬리오시티")
browser.find_element_by_xpath("//*[@id='daumSearch']/fieldset/div/div/button[2]").click()

soup = BeautifulSoup(browser.page_source, "lxml")

# with open("quiz.html", "w", encoding="utf8") as f:
#     f.write(soup.prettify())

data_rows = soup.find("table", attrs={"class":"tbl"}).find("tbody").find_all("tr")

for idx, row in enumerate(data_rows):
    columns = row.find_all("td")
    deal_type = columns[0].get_text()
    area = columns[1].get_text()
    price = columns[2].get_text()
    place_dong = columns[3].get_text()
    floor = columns[4].get_text()

    print(f"============= 매물{idx} =============")
    print(f"거래 : {deal_type}")
    print(f"면적 : {area} (공급/전용)")
    print(f"가격 : {price} (만원)")
    print(f"동 : {place_dong}")
    print(f"층 : {floor}")

browser.quit()
        
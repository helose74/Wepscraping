import re

p = re.compile("ca.e")
# . (ca.e) : 하나의 문자 ex) care, cafe, case
# ^ (^de) : 문자열의 시작 ex) desk, destination
# $ (se$): 문자열의 끝 ex) case, base

def print_match(m):
    if m:
        print("m.group():", m.group()) #일치하는 문자열 반환
        print("m.string:", m.string) #입력받은 문자열 반환
        print("m.start():", m.start()) #일치하는 문자열의 시작 idx 반환
        print("m.end():", m.end()) #일치하는 문자열의 끝 idx 반환
        print("m.span():", m.span()) #일치하는 문자열의 시작/끝 idx 반환
    else:
        print("매칭되지 않음")

m = p.match("careless") #문자열 처음부터 일치 확인
print(m)
print_match(m)

m = p.search("careless") #문자열 중 일치 확인
print(m)

m = p.findall("careless") #일치하는 모든 것을 리스트 형태로 반환
print(m)